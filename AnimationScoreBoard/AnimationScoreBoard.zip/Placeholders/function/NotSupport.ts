import { NotSupportText } from "../Config";

export const NotSupport = function (): string {
  return NotSupportText;
};
