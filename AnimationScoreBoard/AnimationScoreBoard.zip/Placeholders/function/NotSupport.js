"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotSupport = void 0;
const Config_1 = require("../Config");
const NotSupport = function () {
    return Config_1.NotSupportText;
};
exports.NotSupport = NotSupport;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiTm90U3VwcG9ydC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIk5vdFN1cHBvcnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEsc0NBQTJDO0FBRXBDLE1BQU0sVUFBVSxHQUFHO0lBQ3hCLE9BQU8sdUJBQWMsQ0FBQztBQUN4QixDQUFDLENBQUM7QUFGVyxRQUFBLFVBQVUsY0FFckIifQ==