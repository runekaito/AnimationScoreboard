export const YamlPath = "../AnimationScoreBoard/config.yml";
export const ScoreboardPath = "../AnimationScoreBoard/scoreboards";
export const PlayerScoreboardNowPath = "../AnimationScoreBoard/data";
export const MaxLine = 30;
export const ReloadCommandDescription = "Scoreboard reload command!!";
export const ReloadConsoleText = "Scoreboard reloaded".yellow;
export const ReloadText = "§eScoreboard reloaded";
